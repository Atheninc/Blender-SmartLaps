import bpy
import os
from datetime import datetime

# Variable globale pour l'opérateur
timelapse_op = None
scene_updated = False

def depsgraph_update(dummy):
    global scene_updated
    scene_updated = True

if depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
    bpy.app.handlers.depsgraph_update_post.append(depsgraph_update)

class StartTimelapseRecording(bpy.types.Operator):
    bl_idname = "timelapse.start"
    bl_label = "Start Timelapse Recording"

    _timer = None
    _recording = False

    def execute(self, context):
        global timelapse_op
        if not self._recording:
            output_path = context.scene.timelapse_output_path
            if not output_path:
                self.report({'ERROR'}, "Please specify an output folder.")
                return {'CANCELLED'}

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            rush_folder = os.path.join(bpy.path.abspath(output_path), f"rush_{timestamp}")
            os.makedirs(rush_folder, exist_ok=True)

            context.scene.timelapse_current_rush_path = rush_folder
            context.scene.frame_current = 1

            self._recording = True
            timelapse_op = self
            wm = context.window_manager
            self._timer = wm.event_timer_add(time_step=context.scene.timelapse_interval, window=context.window)
            wm.modal_handler_add(self)
            self.report({'INFO'}, "Timelapse recording started.")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        global scene_updated
        from ..utils.capture import offscreen_capture

        if event.type == 'TIMER' and self._recording:
            if context.scene.timelapse_only_capture_edit_frames:
                if not scene_updated:
                    return {'PASS_THROUGH'}

            scene_updated = False

            frame_number = context.scene.frame_current
            rush_folder = context.scene.timelapse_current_rush_path

            hidden_objects = [obj for obj in context.scene.objects if not obj.visible_get()]
            for obj in hidden_objects:
                obj.hide_render = True

            display_modes = [
                (context.scene.timelapse_display_wireframe, "WIREFRAME"),
                (context.scene.timelapse_display_solid, "SOLID"),
                (context.scene.timelapse_display_material, "MATERIAL"),
                (context.scene.timelapse_display_render, "RENDERED")
            ]

            for mode_enabled, mode in display_modes:
                if mode_enabled:
                    file_path = f"{rush_folder}/timelapse_frame_{frame_number:04d}_{mode.lower()}.png"
                    offscreen_capture(context.scene, mode, context.scene.timelapse_display_overlay, file_path)

            for obj in hidden_objects:
                obj.hide_render = False

            context.scene.frame_set(frame_number + 1)

        return {'PASS_THROUGH'}

    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
        self._recording = False
        self.report({'INFO'}, "Timelapse recording stopped.")
