import bpy
from .start_timelapse import timelapse_op

class PauseTimelapseRecording(bpy.types.Operator):
    bl_idname = "timelapse.pause"
    bl_label = "Pause Timelapse Recording"

    def execute(self, context):
        if timelapse_op and timelapse_op._recording:
            timelapse_op._recording = False
            self.report({'INFO'}, "Timelapse recording paused.")
        else:
            self.report({'INFO'}, "No recording to pause.")
        return {'FINISHED'}
