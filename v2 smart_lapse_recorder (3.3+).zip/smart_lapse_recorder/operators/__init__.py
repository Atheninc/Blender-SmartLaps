import bpy
from .start_timelapse import StartTimelapseRecording
from .pause_timelapse import PauseTimelapseRecording
from .stop_timelapse import StopTimelapseRecording

classes = [
    StartTimelapseRecording,
    PauseTimelapseRecording,
    StopTimelapseRecording,
]

def register_operators():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister_operators():
    for cls in classes:
        bpy.utils.unregister_class(cls)
