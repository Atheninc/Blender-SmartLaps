import bpy
from .start_timelapse import timelapse_op

class StopTimelapseRecording(bpy.types.Operator):
    bl_idname = "timelapse.stop"
    bl_label = "Stop Timelapse Recording"

    def execute(self, context):
        if timelapse_op and timelapse_op._recording:
            timelapse_op.cancel(context)
        else:
            self.report({'INFO'}, "No recording to stop.")
        return {'FINISHED'}
