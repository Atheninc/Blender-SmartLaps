import bpy

def register_properties():
    bpy.types.Scene.timelapse_interval = bpy.props.FloatProperty(
        name="Interval",
        description="Interval between frames (in seconds)",
        default=1.0,
        min=0.1,
    )
    bpy.types.Scene.timelapse_output_path = bpy.props.StringProperty(
        name="Output Path",
        description="Folder to save timelapse frames",
        default="//timelapse_frames",
        subtype='DIR_PATH',
    )
    bpy.types.Scene.timelapse_current_rush_path = bpy.props.StringProperty(
        name="Current Rush Path",
        description="Path to the current rush folder",
        default=""
    )

    bpy.types.Scene.timelapse_display_wireframe = bpy.props.BoolProperty(
        name="Wireframe",
        description="Enable wireframe display during recording",
        default=False
    )
    bpy.types.Scene.timelapse_display_solid = bpy.props.BoolProperty(
        name="Solid",
        description="Enable solid display during recording",
        default=False
    )
    bpy.types.Scene.timelapse_display_material = bpy.props.BoolProperty(
        name="Material",
        description="Enable material display during recording",
        default=False
    )
    bpy.types.Scene.timelapse_display_render = bpy.props.BoolProperty(
        name="Render",
        description="Enable render display during recording",
        default=False
    )
    bpy.types.Scene.timelapse_display_overlay = bpy.props.BoolProperty(
        name="Display Overlay",
        description="Enable overlay display during recording",
        default=True
    )
    bpy.types.Scene.timelapse_only_capture_edit_frames = bpy.props.BoolProperty(
        name="Only Capture Edit Frames",
        description="Capture frames only if there are changes in the scene",
        default=False
    )

    def camera_items(self, context):
        items = []
        for obj in bpy.data.objects:
            if obj.type == 'CAMERA':
                items.append((obj.name, obj.name, ""))
        return items

    bpy.types.Scene.timelapse_camera = bpy.props.EnumProperty(
        name="Camera",
        description="Camera to use for timelapse",
        items=camera_items
    )

def unregister_properties():
    del bpy.types.Scene.timelapse_interval
    del bpy.types.Scene.timelapse_output_path
    del bpy.types.Scene.timelapse_current_rush_path
    del bpy.types.Scene.timelapse_camera
    del bpy.types.Scene.timelapse_display_wireframe
    del bpy.types.Scene.timelapse_display_solid
    del bpy.types.Scene.timelapse_display_material
    del bpy.types.Scene.timelapse_display_render
    del bpy.types.Scene.timelapse_display_overlay
    del bpy.types.Scene.timelapse_only_capture_edit_frames
