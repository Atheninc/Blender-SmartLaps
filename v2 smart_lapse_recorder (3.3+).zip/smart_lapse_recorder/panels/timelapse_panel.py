import bpy

class TimelapseRecorderPanel(bpy.types.Panel):
    bl_label = "Timelapse Recorder"
    bl_idname = "VIEW3D_PT_timelapse_recorder"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Timelapse Recorder'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "timelapse_output_path", text="Output Folder")
        layout.prop(scene, "timelapse_interval", text="Interval (s)")

        layout.label(text="Camera:")
        layout.prop(scene, "timelapse_camera", text="")

        layout.label(text="Display Modes:")
        layout.prop(scene, "timelapse_display_wireframe", text="Wireframe")
        layout.prop(scene, "timelapse_display_solid", text="Solid")
        layout.prop(scene, "timelapse_display_material", text="Material")
        layout.prop(scene, "timelapse_display_render", text="Render")

        layout.prop(scene, "timelapse_display_overlay", text="Display Overlay")
        layout.prop(scene, "timelapse_only_capture_edit_frames", text="Only Capture Edit Frames")

        layout.operator("timelapse.start", text="Start Recording")
        layout.operator("timelapse.pause", text="Pause Recording")
        layout.operator("timelapse.stop", text="Stop Recording")
