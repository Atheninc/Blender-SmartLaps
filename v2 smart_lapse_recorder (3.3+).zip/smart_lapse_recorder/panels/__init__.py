import bpy
from .timelapse_panel import TimelapseRecorderPanel

classes = [TimelapseRecorderPanel]

def register_panels():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister_panels():
    for cls in classes:
        bpy.utils.unregister_class(cls)
