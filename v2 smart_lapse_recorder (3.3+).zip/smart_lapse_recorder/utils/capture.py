import bpy

def offscreen_capture(scene, mode, overlay, filepath):
    # Trouver une aire VIEW_3D existante
    area = None
    for screen in bpy.data.screens:
        for a in screen.areas:
            if a.type == 'VIEW_3D':
                area = a
                break
        if area:
            break

    if not area:
        print("Aucune aire VIEW_3D trouvée.")
        return

    space = area.spaces.active
    region_3d = None
    for region in area.regions:
        if region.type == 'WINDOW':
            region_3d = region
            break

    if region_3d is None:
        print("Aucune region 3D trouvée.")
        return

    # Sauvegarde de l'état initial
    old_type = space.shading.type
    old_overlay = space.overlay.show_overlays
    old_persp = space.region_3d.view_perspective
    old_camera = space.camera

    # Appliquer les nouveaux réglages
    space.shading.type = mode
    space.overlay.show_overlays = overlay

    # Si une caméra est sélectionnée, on l'utilise
    if scene.timelapse_camera and scene.timelapse_camera in bpy.data.objects:
        scene.camera = bpy.data.objects[scene.timelapse_camera]
        space.camera = scene.camera
        space.region_3d.view_perspective = 'CAMERA'

    scene.render.filepath = filepath

    override = {
        'window': bpy.context.window,
        'screen': area.id_data,
        'area': area,
        'region': region_3d,
        'scene': scene,
    }

    # Capture OpenGL
    bpy.ops.render.opengl(override, write_still=True, view_context=True)

    # Restauration des paramètres
    space.shading.type = old_type
    space.overlay.show_overlays = old_overlay
    space.region_3d.view_perspective = old_persp
    space.camera = old_camera
