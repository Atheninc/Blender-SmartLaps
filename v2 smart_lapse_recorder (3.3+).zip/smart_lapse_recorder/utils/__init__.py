# Ce fichier peut rester vide, il indique que "utils" est un package Python.
