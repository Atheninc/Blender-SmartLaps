bl_info = {
    "name": "Smart Lapse Recorder",
    "blender": (2, 80, 0),
    "category": "3D View",
    "version": (0, 4, 0),
    "author": "Adrien de Tena",
    "description": "Addon pour simplifier la production de timelapses stylisés sur Blender",
}

import bpy
from . import properties
from .operators import register_operators, unregister_operators
from .panels import register_panels, unregister_panels

def register():
    properties.register_properties()
    register_operators()
    register_panels()

def unregister():
    unregister_panels()
    unregister_operators()
    properties.unregister_properties()

if __name__ == "__main__":
    register()
